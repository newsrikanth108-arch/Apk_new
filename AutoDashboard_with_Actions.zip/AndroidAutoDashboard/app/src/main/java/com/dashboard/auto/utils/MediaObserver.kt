package com.dashboard.auto.utils

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import androidx.core.content.getSystemService
import com.dashboard.auto.data.DashboardRepository
import com.dashboard.auto.data.MediaData
import com.dashboard.auto.service.NotificationService

/**
 * Reads the active MediaSession to get now-playing track info.
 * Requires BIND_NOTIFICATION_LISTENER_SERVICE permission + user grant.
 */
object MediaObserver {

    fun refreshMediaState(context: Context) {
        try {
            val msm = context.getSystemService<MediaSessionManager>() ?: return
            val cn = ComponentName(context, NotificationService::class.java)
            val controllers: List<MediaController> = msm.getActiveSessions(cn)

            if (controllers.isEmpty()) {
                DashboardRepository.updateMedia(MediaData())
                return
            }

            val active = controllers.firstOrNull { c ->
                c.playbackState?.state == PlaybackState.STATE_PLAYING
            } ?: controllers.first()

            val meta: MediaMetadata? = active.metadata
            val ps: PlaybackState? = active.playbackState

            val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Unknown Track"
            val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: "Unknown Artist"
            val album = meta?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
            val duration = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            val position = ps?.position ?: 0L
            val isPlaying = ps?.state == PlaybackState.STATE_PLAYING

            // Get source app name from package
            val appName = try {
                val pm = context.packageManager
                val appInfo = pm.getApplicationInfo(active.packageName, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                active.packageName
            }

            DashboardRepository.updateMedia(
                MediaData(
                    title = title,
                    artist = artist,
                    album = album,
                    appName = appName,
                    isPlaying = isPlaying,
                    durationMs = duration,
                    positionMs = position
                )
            )
        } catch (e: SecurityException) {
            // Notification listener permission not granted
            DashboardRepository.updateMedia(
                MediaData(title = "Enable Notification Access", artist = "Settings → Notification Access")
            )
        } catch (e: Exception) {
            DashboardRepository.updateMedia(MediaData())
        }
    }
}
