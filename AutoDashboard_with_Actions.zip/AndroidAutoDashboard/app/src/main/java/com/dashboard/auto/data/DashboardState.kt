package com.dashboard.auto.data

/**
 * Central data model holding live state for all dashboard widgets.
 * Updated by LocationService, MediaObserver, WeatherRepository.
 * Observed by the CarAppService to refresh the Auto screen.
 */

data class SpeedData(
    val speedKmh: Float = 0f,
    val speedMph: Float = 0f,
    val maxSpeedKmh: Float = 0f,
    val accuracy: Float = 0f,
    val isGpsActive: Boolean = false
)

data class WeatherData(
    val temperature: String = "--",
    val condition: String = "Loading...",
    val humidity: String = "--",
    val windSpeed: String = "--",
    val feelsLike: String = "--",
    val iconCode: String = "01d",
    val cityName: String = "Locating...",
    val isLoaded: Boolean = false
)

data class MediaData(
    val title: String = "Nothing Playing",
    val artist: String = "",
    val album: String = "",
    val appName: String = "Music",
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L
)

data class NavigationData(
    val currentAddress: String = "Getting location...",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val hasLocation: Boolean = false
)

data class DashboardState(
    val speed: SpeedData = SpeedData(),
    val weather: WeatherData = WeatherData(),
    val media: MediaData = MediaData(),
    val navigation: NavigationData = NavigationData(),
    val lastUpdated: Long = System.currentTimeMillis()
)
