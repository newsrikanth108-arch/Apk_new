package com.dashboard.auto.screens

import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.model.Toggle
import com.dashboard.auto.data.DashboardRepository

/**
 * Settings screen accessible from the home screen action strip.
 * Allows toggling widgets and viewing status info.
 */
class SettingsScreen(carContext: CarContext) : Screen(carContext) {

    private var showMph = false

    override fun onGetTemplate(): Template {
        val state = DashboardRepository.getCurrent()

        val items = ItemList.Builder()
            .addItem(
                Row.Builder()
                    .setTitle("Speed Unit")
                    .addText(if (showMph) "mph" else "km/h")
                    .setToggle(Toggle.Builder { isChecked ->
                        showMph = isChecked
                        invalidate()
                        CarToast.makeText(
                            carContext,
                            if (isChecked) "Showing mph" else "Showing km/h",
                            CarToast.LENGTH_SHORT
                        ).show()
                    }.setChecked(showMph).build())
                    .build()
            )
            .addItem(
                Row.Builder()
                    .setTitle("GPS Status")
                    .addText(
                        if (state.speed.isGpsActive)
                            "Active — Accuracy: ±${"%.0f".format(state.speed.accuracy)}m"
                        else
                            "Inactive — Check location permission"
                    )
                    .build()
            )
            .addItem(
                Row.Builder()
                    .setTitle("Weather Source")
                    .addText("Open-Meteo (free, no API key) · ${state.weather.cityName}")
                    .build()
            )
            .addItem(
                Row.Builder()
                    .setTitle("Notification Access")
                    .addText("Required for Now Playing widget. Grant in Android Settings → Apps → Special Access.")
                    .build()
            )
            .addItem(
                Row.Builder()
                    .setTitle("About")
                    .addText("Auto Dashboard v1.0 · GPS Speedometer · Live Weather · Now Playing · Maps")
                    .build()
            )
            .build()

        return ListTemplate.Builder()
            .setTitle("Dashboard Settings")
            .setHeaderAction(Action.BACK)
            .setSingleList(items)
            .build()
    }
}
