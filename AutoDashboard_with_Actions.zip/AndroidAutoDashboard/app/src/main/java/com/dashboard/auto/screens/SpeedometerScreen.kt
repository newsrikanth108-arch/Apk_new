package com.dashboard.auto.screens

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.dashboard.auto.R
import com.dashboard.auto.data.DashboardRepository

/**
 * Full-screen speedometer detail.
 * Shows current speed, max speed, GPS accuracy, and unit conversion.
 */
class SpeedometerScreen(carContext: CarContext) : Screen(carContext) {

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) {
                DashboardRepository.state.observeForever { _ -> invalidate() }
            }
        })
    }

    override fun onGetTemplate(): Template {
        val speed = DashboardRepository.getCurrent().speed

        val title = if (speed.isGpsActive) {
            "${"%.1f".format(speed.speedKmh)} km/h"
        } else {
            "GPS Inactive"
        }

        val message = buildString {
            appendLine("Speed: ${"%.1f".format(speed.speedKmh)} km/h")
            appendLine("       ${"%.1f".format(speed.speedMph)} mph")
            appendLine("       ${"%.1f".format(speed.speedKmh / 3.6f)} m/s")
            appendLine()
            appendLine("Max Speed: ${"%.1f".format(speed.maxSpeedKmh)} km/h")
            appendLine("GPS Accuracy: ±${"%.0f".format(speed.accuracy)} m")
            appendLine()
            if (!speed.isGpsActive) {
                appendLine("⚠️ Enable location permission and ensure GPS signal.")
            } else {
                val status = when {
                    speed.speedKmh < 5 -> "🟢 Stationary"
                    speed.speedKmh < 60 -> "🟢 City Speed"
                    speed.speedKmh < 100 -> "🟡 Highway"
                    speed.speedKmh < 130 -> "🟠 Fast"
                    else -> "🔴 Very Fast"
                }
                appendLine(status)
            }
        }

        val iconTint = when {
            speed.speedKmh > 120 -> CarColor.RED
            speed.speedKmh > 80 -> CarColor.YELLOW
            else -> CarColor.GREEN
        }

        return MessageTemplate.Builder(message)
            .setTitle(title)
            .setHeaderAction(Action.BACK)
            .setIcon(
                CarIcon.Builder(
                    IconCompat.createWithResource(carContext, R.drawable.ic_speed)
                ).setTint(iconTint).build()
            )
            .build()
    }
}
