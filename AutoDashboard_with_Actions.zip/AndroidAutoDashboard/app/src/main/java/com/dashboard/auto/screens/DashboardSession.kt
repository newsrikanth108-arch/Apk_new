package com.dashboard.auto.screens

import android.content.Intent
import androidx.car.app.Screen
import androidx.car.app.Session
import com.dashboard.auto.service.LocationService

/**
 * DashboardSession is created once per Android Auto connection.
 * It starts the LocationService and returns the HomeScreen as the root.
 */
class DashboardSession : Session() {

    override fun onCreateScreen(intent: Intent): Screen {
        // Start GPS service so speedometer and weather work
        carContext.startForegroundService(Intent(carContext, LocationService::class.java))
        return HomeScreen(carContext)
    }

    override fun onNewIntent(intent: Intent) {
        // Handle deep links if needed in future
    }
}
