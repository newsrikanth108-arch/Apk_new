package com.dashboard.auto.screens

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.dashboard.auto.R
import com.dashboard.auto.data.DashboardRepository

/**
 * Shows currently playing media in detail.
 * Note: Media controls (play/pause/skip) are handled by Android Auto's built-in
 * media app integration — this screen just mirrors the now-playing info.
 */
class MediaScreen(carContext: CarContext) : Screen(carContext) {

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) {
                DashboardRepository.state.observeForever { _ -> invalidate() }
            }
        })
    }

    override fun onGetTemplate(): Template {
        val m = DashboardRepository.getCurrent().media

        val message = buildString {
            appendLine(if (m.isPlaying) "▶ Now Playing" else "⏸ Paused")
            appendLine()
            appendLine("🎵  ${m.title}")
            if (m.artist.isNotBlank()) appendLine("🎤  ${m.artist}")
            if (m.album.isNotBlank()) appendLine("💿  ${m.album}")
            appendLine()
            appendLine("App: ${m.appName}")
            appendLine()
            if (m.durationMs > 0) {
                val pos = formatMs(m.positionMs)
                val dur = formatMs(m.durationMs)
                appendLine("⏱  $pos / $dur")
            }
            appendLine()
            appendLine("ℹ️  Use your music app in Android Auto for full controls.")
            appendLine()
            appendLine("Note: If 'Enable Notification Access' is shown on the")
            appendLine("home tile, go to Settings → Notifications → Notification")
            appendLine("Access → Auto Dashboard → Enable.")
        }

        return MessageTemplate.Builder(message)
            .setTitle(if (m.title.isNotBlank()) m.title else "No Media")
            .setHeaderAction(Action.BACK)
            .setIcon(
                CarIcon.Builder(
                    IconCompat.createWithResource(carContext, R.drawable.ic_music)
                ).setTint(CarColor.BLUE).build()
            )
            .build()
    }

    private fun formatMs(ms: Long): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return "%d:%02d".format(min, sec)
    }
}
