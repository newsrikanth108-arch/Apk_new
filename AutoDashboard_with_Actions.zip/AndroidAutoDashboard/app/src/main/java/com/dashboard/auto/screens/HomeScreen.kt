package com.dashboard.auto.screens

import android.content.Intent
import android.net.Uri
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.dashboard.auto.R
import com.dashboard.auto.data.DashboardRepository
import com.dashboard.auto.data.DashboardState

/**
 * HomeScreen renders the main Android Auto dashboard using a GridTemplate.
 * The Car App Library's GridTemplate gives us a 2×2 or 2×3 grid of tiles —
 * each tile is one widget: Speed, Weather, Music, Navigation.
 *
 * The screen observes DashboardRepository and calls invalidate() to refresh
 * whenever data changes, triggering onGetTemplate() again.
 */
class HomeScreen(carContext: CarContext) : Screen(carContext) {

    init {
        // Observe live state from repository
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) {
                DashboardRepository.state.observeForever { _ ->
                    invalidate() // Triggers onGetTemplate()
                }
            }
        })
    }

    override fun onGetTemplate(): Template {
        val state = DashboardRepository.getCurrent()

        return GridTemplate.Builder()
            .setTitle("Auto Dashboard")
            .setHeaderAction(Action.APP_ICON)
            .setActionStrip(buildActionStrip())
            .setSingleList(buildWidgetGrid(state))
            .build()
    }

    // ─── Action strip (top-right buttons) ────────────────────────────────────
    private fun buildActionStrip(): ActionStrip {
        return ActionStrip.Builder()
            .addAction(
                Action.Builder()
                    .setTitle("Settings")
                    .setOnClickListener {
                        screenManager.push(SettingsScreen(carContext))
                    }
                    .build()
            )
            .build()
    }

    // ─── 2×2 Widget Grid ─────────────────────────────────────────────────────
    private fun buildWidgetGrid(state: DashboardState): ItemList {
        return ItemList.Builder()
            .addItem(buildSpeedWidget(state))
            .addItem(buildWeatherWidget(state))
            .addItem(buildMusicWidget(state))
            .addItem(buildNavigationWidget(state))
            .build()
    }

    // ─── Widget 1: GPS Speedometer ───────────────────────────────────────────
    private fun buildSpeedWidget(state: DashboardState): GridItem {
        val speed = state.speed
        val speedText = if (speed.isGpsActive) {
            "${"%.0f".format(speed.speedKmh)} km/h"
        } else {
            "GPS Off"
        }
        val subText = if (speed.isGpsActive) {
            "Max: ${"%.0f".format(speed.maxSpeedKmh)} km/h  ·  ${"%.0f".format(speed.speedMph)} mph"
        } else {
            "Waiting for GPS signal..."
        }

        return GridItem.Builder()
            .setTitle(speedText)
            .setText(subText)
            .setImage(
                CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_speed))
                    .setTint(if (speed.speedKmh > 120) CarColor.RED else CarColor.GREEN)
                    .build()
            )
            .setOnClickListener {
                screenManager.push(SpeedometerScreen(carContext))
            }
            .build()
    }

    // ─── Widget 2: Weather ───────────────────────────────────────────────────
    private fun buildWeatherWidget(state: DashboardState): GridItem {
        val weather = state.weather
        val title = if (weather.isLoaded) {
            "${weather.temperature}  ${weather.condition}"
        } else {
            "Loading weather..."
        }
        val subText = if (weather.isLoaded) {
            "${weather.cityName}  ·  ${weather.humidity} humidity  ·  ${weather.windSpeed} wind"
        } else {
            "Getting location..."
        }

        return GridItem.Builder()
            .setTitle(title)
            .setText(subText)
            .setImage(
                CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_weather))
                    .setTint(CarColor.YELLOW)
                    .build()
            )
            .setOnClickListener {
                screenManager.push(WeatherScreen(carContext))
            }
            .build()
    }

    // ─── Widget 3: Now Playing Music ─────────────────────────────────────────
    private fun buildMusicWidget(state: DashboardState): GridItem {
        val media = state.media
        val title = if (media.isPlaying) "▶ ${media.title}" else "⏸ ${media.title}"
        val subText = buildString {
            if (media.artist.isNotBlank()) append(media.artist)
            if (media.appName.isNotBlank()) append("  ·  ${media.appName}")
        }.ifBlank { "No media playing" }

        return GridItem.Builder()
            .setTitle(title)
            .setText(subText)
            .setImage(
                CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_music))
                    .setTint(CarColor.BLUE)
                    .build()
            )
            .setOnClickListener {
                screenManager.push(MediaScreen(carContext))
            }
            .build()
    }

    // ─── Widget 4: Navigation / Maps ─────────────────────────────────────────
    private fun buildNavigationWidget(state: DashboardState): GridItem {
        val nav = state.navigation
        val title = if (nav.hasLocation) "Navigation" else "Getting Location..."
        val subText = nav.currentAddress

        return GridItem.Builder()
            .setTitle(title)
            .setText(subText)
            .setImage(
                CarIcon.Builder(IconCompat.createWithResource(carContext, R.drawable.ic_navigation))
                    .setTint(CarColor.createCustom(0xFF58A6FF.toInt(), 0xFF1F6FEB.toInt()))
                    .build()
            )
            .setOnClickListener {
                // Open Google Maps in Android Auto / phone
                if (nav.hasLocation) {
                    val uri = Uri.parse("google.navigation:q=${nav.latitude},${nav.longitude}&mode=d")
                    val mapIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        setPackage("com.google.android.apps.maps")
                    }
                    try {
                        carContext.startActivity(mapIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e: Exception) {
                        CarToast.makeText(carContext, "Google Maps not available", CarToast.LENGTH_SHORT).show()
                    }
                } else {
                    CarToast.makeText(carContext, "Waiting for GPS...", CarToast.LENGTH_SHORT).show()
                }
            }
            .build()
    }
}
