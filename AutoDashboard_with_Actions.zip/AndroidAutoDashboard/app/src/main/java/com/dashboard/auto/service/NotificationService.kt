package com.dashboard.auto.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.dashboard.auto.utils.MediaObserver

/**
 * NotificationListenerService stub.
 * This is required to call MediaSessionManager.getActiveSessions().
 * The user must grant "Notification Access" in Settings for this to work.
 *
 * Go to: Settings → Notifications → Notification Access → Auto Dashboard → Enable
 */
class NotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        MediaObserver.refreshMediaState(applicationContext)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        MediaObserver.refreshMediaState(applicationContext)
    }
}
