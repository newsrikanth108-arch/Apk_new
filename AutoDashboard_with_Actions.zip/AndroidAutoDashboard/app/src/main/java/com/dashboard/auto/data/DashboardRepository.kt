package com.dashboard.auto.data

import androidx.lifecycle.MutableLiveData

/**
 * Singleton repository that acts as the single source of truth for all
 * dashboard widget data. Services write here; screens observe here.
 */
object DashboardRepository {

    val state = MutableLiveData(DashboardState())

    fun updateSpeed(speed: SpeedData) {
        val current = state.value ?: DashboardState()
        state.postValue(current.copy(speed = speed, lastUpdated = System.currentTimeMillis()))
    }

    fun updateWeather(weather: WeatherData) {
        val current = state.value ?: DashboardState()
        state.postValue(current.copy(weather = weather, lastUpdated = System.currentTimeMillis()))
    }

    fun updateMedia(media: MediaData) {
        val current = state.value ?: DashboardState()
        state.postValue(current.copy(media = media, lastUpdated = System.currentTimeMillis()))
    }

    fun updateNavigation(nav: NavigationData) {
        val current = state.value ?: DashboardState()
        state.postValue(current.copy(navigation = nav, lastUpdated = System.currentTimeMillis()))
    }

    fun getCurrent(): DashboardState = state.value ?: DashboardState()
}
