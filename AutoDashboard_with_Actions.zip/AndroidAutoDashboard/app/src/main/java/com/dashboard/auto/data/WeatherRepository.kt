package com.dashboard.auto.data

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Fetches weather from Open-Meteo API - completely free, no API key required.
 * URL format: https://api.open-meteo.com/v1/forecast?latitude=LAT&longitude=LON
 *             &current=temperature_2m,weathercode,windspeed_10m,relativehumidity_2m,apparent_temperature
 *
 * For city name, uses Open-Meteo Geocoding reverse lookup.
 */
object WeatherRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    private const val TAG = "WeatherRepo"

    // WMO Weather interpretation codes → human readable
    private val wmoConditions = mapOf(
        0 to "Clear Sky", 1 to "Mainly Clear", 2 to "Partly Cloudy", 3 to "Overcast",
        45 to "Foggy", 48 to "Icy Fog",
        51 to "Light Drizzle", 53 to "Drizzle", 55 to "Heavy Drizzle",
        61 to "Light Rain", 63 to "Rain", 65 to "Heavy Rain",
        71 to "Light Snow", 73 to "Snow", 75 to "Heavy Snow",
        80 to "Showers", 81 to "Rain Showers", 82 to "Violent Showers",
        95 to "Thunderstorm", 96 to "Thunderstorm + Hail", 99 to "Heavy Thunderstorm"
    )

    suspend fun fetchWeather(lat: Double, lon: Double): WeatherData = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weathercode,windspeed_10m,relativehumidity_2m,apparent_temperature" +
                    "&timezone=auto"

            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext WeatherData(condition = "No data")

            val json = JSONObject(body)
            val current = json.getJSONObject("current")
            val temp = current.getDouble("temperature_2m")
            val feelsLike = current.getDouble("apparent_temperature")
            val humidity = current.getInt("relativehumidity_2m")
            val wind = current.getDouble("windspeed_10m")
            val code = current.getInt("weathercode")

            val cityName = fetchCityName(lat, lon)

            WeatherData(
                temperature = "${temp.toInt()}°C",
                condition = wmoConditions[code] ?: "Unknown",
                humidity = "$humidity%",
                windSpeed = "${wind.toInt()} km/h",
                feelsLike = "Feels ${feelsLike.toInt()}°C",
                iconCode = wmoToEmoji(code),
                cityName = cityName,
                isLoaded = true
            )
        } catch (e: Exception) {
            Log.e(TAG, "Weather fetch failed: ${e.message}")
            WeatherData(condition = "Unavailable", isLoaded = true)
        }
    }

    private suspend fun fetchCityName(lat: Double, lon: Double): String = withContext(Dispatchers.IO) {
        try {
            // Use open-meteo's geocoding for reverse lookup (or nominatim)
            val url = "https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=json"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "AutoDashboard/1.0")
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext "Unknown Location"
            val json = JSONObject(body)
            val address = json.optJSONObject("address")
            address?.optString("city")
                ?: address?.optString("town")
                ?: address?.optString("village")
                ?: address?.optString("county")
                ?: "Unknown Location"
        } catch (e: Exception) {
            "Unknown Location"
        }
    }

    private fun wmoToEmoji(code: Int): String = when (code) {
        0, 1 -> "☀️"
        2, 3 -> "⛅"
        45, 48 -> "🌫️"
        51, 53, 55, 61, 63, 65, 80, 81, 82 -> "🌧️"
        71, 73, 75 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌤️"
    }
}
