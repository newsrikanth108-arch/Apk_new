package com.dashboard.auto

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.dashboard.auto.service.LocationService
import com.dashboard.auto.service.NotificationService

/**
 * Phone-side Activity.
 * - Requests location permission
 * - Guides user to grant Notification Listener access
 * - Starts the LocationService
 * - Shows dashboard status
 */
class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnGrantLocation: Button
    private lateinit var btnGrantNotification: Button
    private lateinit var btnStartService: Button
    private lateinit var btnOpenAutoSettings: Button

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        updateStatus()
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            startLocationService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        btnGrantLocation = findViewById(R.id.btnGrantLocation)
        btnGrantNotification = findViewById(R.id.btnGrantNotification)
        btnStartService = findViewById(R.id.btnStartService)
        btnOpenAutoSettings = findViewById(R.id.btnOpenAutoSettings)

        btnGrantLocation.setOnClickListener { requestLocationPermission() }

        btnGrantNotification.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        btnStartService.setOnClickListener { startLocationService() }

        btnOpenAutoSettings.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_MAIN).apply {
                    setPackage("com.google.android.projection.gearhead")
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.projection.gearhead")))
            }
        }

        // Auto-request location on first launch
        if (!hasLocationPermission()) {
            requestLocationPermission()
        } else {
            startLocationService()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val sb = StringBuilder()
        sb.appendLine("=== Auto Dashboard Status ===\n")

        val locGranted = hasLocationPermission()
        sb.appendLine("📍 Location Permission: ${if (locGranted) "✅ Granted" else "❌ Not Granted"}")

        val notifGranted = isNotificationListenerEnabled()
        sb.appendLine("🔔 Notification Access: ${if (notifGranted) "✅ Granted" else "❌ Not Granted (Music widget needs this)"}")

        sb.appendLine()
        sb.appendLine("=== How to use ===")
        sb.appendLine("1. Grant Location permission above")
        sb.appendLine("2. Grant Notification Access above")
        sb.appendLine("3. Connect phone to car with Android Auto")
        sb.appendLine("   OR use DHU emulator on your PC")
        sb.appendLine("4. Open 'Auto Dashboard' on the car screen")
        sb.appendLine()
        sb.appendLine("=== Android Auto DHU Testing ===")
        sb.appendLine("1. Enable Developer Options on phone")
        sb.appendLine("2. Enable USB Debugging")
        sb.appendLine("3. Install DHU on PC from Android SDK")
        sb.appendLine("4. Run: adb forward tcp:5277 tcp:5277")
        sb.appendLine("5. Run: desktop-head-unit.exe (Windows)")

        statusText.text = sb.toString()

        btnGrantLocation.isEnabled = !locGranted
        btnGrantNotification.isEnabled = !notifGranted
    }

    private fun requestLocationPermission() {
        locationPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )
    }

    private fun startLocationService() {
        if (!hasLocationPermission()) return
        val intent = Intent(this, LocationService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )
        if (TextUtils.isEmpty(enabledListeners)) return false
        val cn = ComponentName(this, NotificationService::class.java)
        return enabledListeners.contains(cn.flattenToString())
    }
}
