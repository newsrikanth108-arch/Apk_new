package com.dashboard.auto.service

import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import com.dashboard.auto.screens.DashboardSession

/**
 * The CarAppService is the entry point for Android Auto.
 * When you open the app on the head unit (or DHU emulator),
 * Android Auto connects to this service.
 */
class DashboardCarAppService : CarAppService() {

    override fun createHostValidator(): HostValidator {
        // During development: allow all hosts.
        // For production: use HostValidator.Builder to whitelist known Auto hosts.
        return if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
        } else {
            HostValidator.Builder(applicationContext)
                .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
                .build()
        }
    }

    override fun onCreateSession(): Session {
        return DashboardSession()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}
