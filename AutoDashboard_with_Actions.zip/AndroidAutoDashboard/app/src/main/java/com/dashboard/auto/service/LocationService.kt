package com.dashboard.auto.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.dashboard.auto.R
import com.dashboard.auto.data.DashboardRepository
import com.dashboard.auto.data.NavigationData
import com.dashboard.auto.data.SpeedData
import com.dashboard.auto.data.WeatherRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Foreground service that:
 * 1. Reads GPS location at 1-second intervals
 * 2. Computes speed from GPS (km/h and mph)
 * 3. Triggers weather fetch when location changes significantly (>500m)
 * 4. Updates DashboardRepository with fresh data
 */
class LocationService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var lastWeatherLat = 0.0
    private var lastWeatherLon = 0.0
    private var maxSpeedKmh = 0f

    companion object {
        const val CHANNEL_ID = "dashboard_location"
        const val NOTIFICATION_ID = 1001
        private const val TAG = "LocationService"
        private const val WEATHER_UPDATE_DISTANCE_M = 500f
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc: Location = result.lastLocation ?: return

            // Speed: GPS gives m/s, convert to km/h and mph
            val speedMs = if (loc.hasSpeed()) loc.speed else 0f
            val speedKmh = speedMs * 3.6f
            val speedMph = speedMs * 2.237f
            if (speedKmh > maxSpeedKmh) maxSpeedKmh = speedKmh

            DashboardRepository.updateSpeed(
                SpeedData(
                    speedKmh = speedKmh,
                    speedMph = speedMph,
                    maxSpeedKmh = maxSpeedKmh,
                    accuracy = loc.accuracy,
                    isGpsActive = true
                )
            )

            DashboardRepository.updateNavigation(
                NavigationData(
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    hasLocation = true,
                    currentAddress = "Lat: ${"%.4f".format(loc.latitude)}, Lon: ${"%.4f".format(loc.longitude)}"
                )
            )

            // Fetch weather only when moved >500m from last fetch
            val distFromLastWeather = FloatArray(1)
            Location.distanceBetween(lastWeatherLat, lastWeatherLon, loc.latitude, loc.longitude, distFromLastWeather)
            if (distFromLastWeather[0] > WEATHER_UPDATE_DISTANCE_M || lastWeatherLat == 0.0) {
                lastWeatherLat = loc.latitude
                lastWeatherLon = loc.longitude
                serviceScope.launch {
                    val weather = WeatherRepository.fetchWeather(loc.latitude, loc.longitude)
                    DashboardRepository.updateWeather(weather)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Location permission not granted, stopping service")
            stopSelf()
            return
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L)
            .setMinUpdateDistanceMeters(0f)
            .build()

        fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        DashboardRepository.updateSpeed(SpeedData(isGpsActive = false))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Dashboard Location",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Tracks GPS speed for the dashboard speedometer"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Auto Dashboard Active")
            .setContentText("GPS speedometer is running")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
