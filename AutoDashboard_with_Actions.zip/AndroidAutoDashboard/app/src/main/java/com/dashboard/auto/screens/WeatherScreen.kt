package com.dashboard.auto.screens

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarColor
import androidx.car.app.model.CarIcon
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.dashboard.auto.R
import com.dashboard.auto.data.DashboardRepository

/**
 * Detailed weather view — shown when the user taps the weather tile.
 */
class WeatherScreen(carContext: CarContext) : Screen(carContext) {

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onResume(owner: LifecycleOwner) {
                DashboardRepository.state.observeForever { _ -> invalidate() }
            }
        })
    }

    override fun onGetTemplate(): Template {
        val w = DashboardRepository.getCurrent().weather

        val message = if (!w.isLoaded) {
            "Fetching weather data...\n\nEnsure location permission is granted."
        } else {
            buildString {
                appendLine("📍 ${w.cityName}")
                appendLine()
                appendLine("${w.iconCode}  ${w.condition}")
                appendLine()
                appendLine("🌡️  Temperature:   ${w.temperature}")
                appendLine("🌡️  ${w.feelsLike}")
                appendLine()
                appendLine("💧 Humidity:       ${w.humidity}")
                appendLine("💨 Wind Speed:    ${w.windSpeed}")
                appendLine()
                appendLine("Data from Open-Meteo (free, no API key)")
            }
        }

        return MessageTemplate.Builder(message)
            .setTitle(if (w.isLoaded) "${w.temperature} — ${w.cityName}" else "Weather")
            .setHeaderAction(Action.BACK)
            .setIcon(
                CarIcon.Builder(
                    IconCompat.createWithResource(carContext, R.drawable.ic_weather)
                ).setTint(CarColor.YELLOW).build()
            )
            .build()
    }
}
