# 🚗 Auto Dashboard — Android Auto Widget App

A fully native Android Auto app with four live dashboard widgets:
- **Speedometer** — GPS-based, km/h + mph, with max speed tracking
- **Weather** — Real-time from Open-Meteo (FREE, no API key needed)
- **Now Playing** — Reads active MediaSession from any music app
- **Navigation** — Shows GPS coordinates, taps to open Google Maps

---

## 📁 Project Structure

```
app/
├── service/
│   ├── DashboardCarAppService.kt   ← Android Auto entry point
│   ├── DashboardSession.kt         ← Creates screen stack on connect
│   ├── LocationService.kt          ← GPS foreground service
│   └── NotificationService.kt      ← For MediaSession access
├── screens/
│   ├── HomeScreen.kt               ← Main 2×2 widget grid
│   ├── SpeedometerScreen.kt        ← Speed detail view
│   ├── WeatherScreen.kt            ← Weather detail view
│   ├── MediaScreen.kt              ← Now Playing detail view
│   └── SettingsScreen.kt           ← Dashboard settings
├── data/
│   ├── DashboardState.kt           ← Data models
│   ├── DashboardRepository.kt      ← LiveData singleton hub
│   └── WeatherRepository.kt        ← Open-Meteo API client
└── utils/
    └── MediaObserver.kt            ← Reads MediaSession
```

---

## 🔧 Build Instructions

### Prerequisites
- **Android Studio Hedgehog** (2023.1.1) or newer
- **JDK 17** (bundled with Android Studio)
- **Android SDK 34**
- A phone running Android 8.0 (API 26) or higher
- Android Auto app installed on the phone

### Steps

1. **Open project**
   ```
   File → Open → Select the AndroidAutoDashboard folder
   ```

2. **Sync Gradle**
   Android Studio will auto-sync. If not: `File → Sync Project with Gradle Files`

3. **Build APK**
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   APK location: `app/build/outputs/apk/debug/app-debug.apk`

4. **Install on phone**
   ```
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
   Or Run directly via Android Studio with phone connected.

---

## 📱 First-Time Setup on Phone

After installing, open **Auto Dashboard** on your phone:

1. **Tap "Grant Location Permission"** — required for speedometer and weather
2. **Tap "Grant Notification Access"** → enable Auto Dashboard in the list
   - This is needed for the Now Playing widget to read your music player

---

## 🚗 Testing with Android Auto

### Option A: Real Car
- Connect phone to car USB, Android Auto will auto-start
- Find "Auto Dashboard" in the app launcher on the car screen

### Option B: Desktop Head Unit (DHU) Emulator — Recommended for Development

1. Open Android Auto on phone
2. Go to: **Settings → Developer Options → Enable Developer Mode**
   (tap "version" 10 times if developer mode not visible)
3. Enable **Unknown sources** in Android Auto
4. On your PC, install DHU from Android SDK:
   ```
   $ANDROID_SDK/extras/google/auto/desktop-head-unit.exe   (Windows)
   $ANDROID_SDK/extras/google/auto/desktop-head-unit        (Mac/Linux)
   ```
5. Connect phone via USB
6. Run on PC:
   ```bash
   adb forward tcp:5277 tcp:5277
   ./desktop-head-unit
   ```
7. Auto Dashboard will appear in the DHU app launcher

---

## 🏠 Set as Default Home Screen

In Android Auto:
1. Tap the **Home** icon on the car screen
2. Long-press the **Auto Dashboard** app icon
3. Select **"Set as default launcher"** (if your head unit supports it)

Alternatively, some head units let you reorder the app grid so Auto Dashboard appears first.

---

## 🌤️ Weather API

Uses **Open-Meteo** — completely free, no registration, no API key:
- `https://api.open-meteo.com/v1/forecast` for weather data
- `https://nominatim.openstreetmap.org/reverse` for city name lookup
- Weather updates automatically when you move >500 meters

---

## 🎵 Now Playing (Music Widget)

Reads the active **MediaSession** from your music app (Spotify, YouTube Music, etc.).

**Requires Notification Access:**
> Settings → Apps → Special App Access → Notification Access → Auto Dashboard → ON

Supported apps: Any app that uses Android MediaSession API (Spotify, YouTube Music, JioSaavn, Wynk, Apple Music, VLC, etc.)

---

## ⚡ Architecture Notes

- Uses **Car App Library 1.4** (the modern, recommended approach for Android Auto)
- `GridTemplate` renders the 2×2 widget dashboard — this is a native Android Auto UI component rendered by the car's head unit
- All data flows through `DashboardRepository` (LiveData singleton)
- `LocationService` runs as a foreground service for continuous GPS
- Weather fetches are throttled — only triggers when you move 500m+
- No third-party map SDK needed — the Navigation widget deep-links to Google Maps

---

## ❗ Important Limitations of Android Auto

Android Auto does **not** allow:
- Custom-rendered UI (no Canvas, no custom Views on car screen)
- Video or camera feeds
- Real embedded maps (only Google Maps via deep-link)
- Arbitrary layouts — only Car App Library templates (Grid, List, Navigation, etc.)

The Car App Library templates (GridTemplate, MessageTemplate, ListTemplate) are what we use — they're rendered natively by the car's display and comply with Android Auto's driver distraction guidelines.

---

## 🔑 Permissions Summary

| Permission | Purpose |
|---|---|
| ACCESS_FINE_LOCATION | GPS speed + weather location |
| INTERNET | Weather API calls |
| FOREGROUND_SERVICE | GPS service keeps running |
| BIND_NOTIFICATION_LISTENER_SERVICE | Read active music player |
| POST_NOTIFICATIONS | Show service notification |

---

## 🐛 Troubleshooting

**App doesn't appear in Android Auto:**
- Make sure `DashboardCarAppService` has the correct intent filter: `androidx.car.app.CarAppService`
- Check that `automotive_app_desc.xml` exists in `res/xml/`

**Speedometer shows 0 always:**
- Check location permission is granted
- Test outdoors for GPS signal

**Music widget shows "Enable Notification Access":**
- Go to Settings → Notification Access → enable for Auto Dashboard

**Weather stuck on "Loading...":**
- Check internet permission
- Ensure GPS gives a fix first (weather needs coordinates)
